# aryaplayer
Kodi add-on for Arya RO streams
This is a player for Romanian local television streams. Mostly distributed trough Arya RO streaming platform.
Feel free to use this plugin.
